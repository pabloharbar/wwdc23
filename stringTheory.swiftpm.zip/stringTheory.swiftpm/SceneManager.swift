//
//  InstrumentManager.swift
//  wwdc23
//
//  Created by Pablo Penas on 25/03/23.
//

import Foundation
import SpriteKit
import SwiftUI

enum Scenes {
    case intro
    case studio
    case string
    case harmonic
    case reflection
    case instrument
}

class SceneManager: ObservableObject {
    var introScene: IntroScene
    var instrumentScene: InstrumentScene
    var stringScene: StringScene
    var studioScene: StudioScene
    var harmonicScene: HarmonicScene
    var reflectionScene: ReflectionScene
    
//    var synthTestScene: SynthTestScene
    
    @Published var currentScene: Scenes
    @Published var instrumentHUDShowing = false
    @Published var harmonicConfig = HarmonicConfig(first: 1, second: 0.1, third: 0.07, fourth: 0, fifth: 0)
    
    init() {
        self.instrumentScene = InstrumentScene()
        self.stringScene = StringScene()
        self.studioScene = StudioScene()
        self.harmonicScene = HarmonicScene()
        self.reflectionScene = ReflectionScene()
        self.introScene = IntroScene()
        
//        self.synthTestScene = SynthTestScene()
//        synthTestScene.scaleMode = .aspectFit
//        synthTestScene.size = CGSize(width: 1910, height: 1200)
        
//        self.currentScene = .string
        self.currentScene = .intro
        
        introScene.scaleMode = .aspectFit
        instrumentScene.scaleMode = .aspectFit
        reflectionScene.scaleMode = .aspectFit
        stringScene.scaleMode = .aspectFit
        studioScene.scaleMode = .aspectFit
        harmonicScene.scaleMode = .aspectFit
        
        introScene.size = CGSize(width: 1910, height: 1200)
        stringScene.size = CGSize(width: 1910, height: 1200)
        instrumentScene.size = CGSize(width: 1910, height: 1200)
        studioScene.size = CGSize(width: 1910, height: 1200)
        harmonicScene.size = CGSize(width: 1910, height: 1200)
        reflectionScene.size = CGSize(width: 1910, height: 1200)
        
        self.studioScene.finishAct = handleStudioActFinish
        self.stringScene.finishAct = handleStringActFinish
        self.harmonicScene.finishAct = handleHarmonicActFinish
        self.reflectionScene.finishAct = handleReflectionActFinish
        self.introScene.finishAct = handleIntroFinish
        self.instrumentScene.openHUD = openInstrumentHUD
    }
    
    func handleStudioActFinish() {
        withAnimation(Animation.easeInOut(duration: 1)) {
            self.currentScene = .string
        }
    }
    
    func handleStringActFinish() {
        withAnimation(Animation.easeInOut(duration: 1)) {
            self.currentScene = .harmonic
        }
    }
    
    func handleHarmonicActFinish() {
        withAnimation(Animation.easeInOut(duration: 1)) {
            self.currentScene = .reflection
        }
    }
    
    func handleReflectionActFinish() {
        withAnimation(Animation.easeInOut(duration: 1)) {
            self.currentScene = .instrument
        }
    }
    
    func handleIntroFinish() {
        withAnimation(Animation.easeInOut(duration: 1)) {
            self.currentScene = .studio
        }
    }
    
    func openInstrumentHUD() {
        self.instrumentHUDShowing = true
    }
}
