import SwiftUI
import SpriteKit

struct ContentView: View {
    @StateObject var sceneManager = SceneManager()
    var body: some View {
        VStack {
            switch sceneManager.currentScene {
            case .intro:
                SpriteView(scene: sceneManager.introScene)
            case .studio:
                SpriteView(scene: sceneManager.studioScene)
            case .string:
                SpriteView(scene: sceneManager.stringScene)
            case .harmonic:
                SpriteView(scene: sceneManager.harmonicScene)
            case .reflection:
                SpriteView(scene: sceneManager.reflectionScene)
            case .instrument:
                SpriteView(scene: sceneManager.instrumentScene)
            }
        }
//        .popover(isPresented: $sceneManager.instrumentHUDShowing, content: {
//            InstrumentHUDView()
//        })
        .fullScreenCover(isPresented: $sceneManager.instrumentHUDShowing) {
            InstrumentHUDView(harmonicConfig: $sceneManager.harmonicConfig)
        }
        .onChange(of: sceneManager.harmonicConfig) { newValue in
            sceneManager.instrumentScene.updateHarmonicConfig(config: newValue)
        }
    }
}
