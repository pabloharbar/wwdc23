//
//  File.swift
//  
//
//  Created by Pablo Penas on 12/04/23.
//

import Foundation
import SpriteKit

class StringSceneManager {
    let speechBank = SpeechBank.shared
    var currentSpeech: String
    var currentSpeechIndex: Int = 0
    
    init() {
        self.currentSpeech = speechBank.stringScene1Speeches[currentSpeechIndex]
    }
    
    func advanceSpeech(sprite: SKSpriteNode) {
        if currentSpeechIndex < speechBank.stringScene1Speeches.count - 1 {
            currentSpeechIndex += 1
            self.currentSpeech = speechBank.stringScene1Speeches[currentSpeechIndex]
            advanceFrame(sprite: sprite)
        }
    }
    
    func advanceFrame(sprite: SKSpriteNode) {
        if currentSpeechIndex < speechBank.stringScene1Images.count {
            let texture = SKTexture(image: UIImage(named: speechBank.stringScene1Images[currentSpeechIndex])!)
            sprite.run(SKAction.setTexture(texture))
        }
    }
}
