//
//  File.swift
//  
//
//  Created by Pablo Penas on 08/04/23.
//

import SpriteKit

class StringWave {
    private var releaseTime: TimeInterval = TimeInterval()
//    private var currentTime: TimeInterval = TimeInterval()
    private var startPoint: CGPoint
    private let endPoint: CGPoint
    private var didRelease: Bool = false
    var vibrationOn: Bool = false
    private let velocity: CGFloat = 5000
    private var releasePoint: CGPoint = CGPoint(x: 0, y: 0)
    var soundOn = false
    var waveNode: SKShapeNode
    let initialLength: CGFloat
    var currentLength: CGFloat
    
    init(start: CGPoint, end: CGPoint) {
        self.waveNode = SKShapeNode()
        self.startPoint = start
        self.endPoint = end
        let path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
        self.waveNode.path = path.cgPath
        self.waveNode.lineWidth = 10
        self.waveNode.strokeColor = UIColor(named: "NeonGreen")!
        self.initialLength = endPoint.x - startPoint.x
        self.currentLength = self.initialLength
    }
    
    func stopString() {
        didRelease = false
        vibrationOn = false
    }
    
    func dragString(pos: CGPoint) {
        let path = UIBezierPath()
        path.move(to: startPoint)
        path.addLine(to: pos)
        path.addLine(to: endPoint)
        waveNode.path = path.cgPath
    }
    
    func releaseString(releasePoint: CGPoint, currentTime: TimeInterval) {
        self.releaseTime = currentTime
        self.releasePoint = releasePoint
        self.didRelease = true
        self.soundOn = true
    }
    
    func updateWaveStartPoint(position: CGPoint, completion: (Float) -> ()) {
        self.startPoint = position
        let path = UIBezierPath()
        path.move(to: startPoint)
        path.addLine(to: endPoint)
        waveNode.path = path.cgPath
        self.currentLength = endPoint.x - startPoint.x
        let contraction: CGFloat = 300
        completion(Float((self.initialLength - contraction)/(self.currentLength - contraction)))
    }
    
    func checkVibrationStart(currentTime: TimeInterval) {
        var updatedReleasePoint = releasePoint
        updatedReleasePoint.y -= (currentTime - releaseTime) * velocity * updatedReleasePoint.y / abs(updatedReleasePoint.y)
        if updatedReleasePoint.y * releasePoint.y < 0 {
            updatedReleasePoint.y = 0
            vibrationOn = true
        }
        dragString(pos: updatedReleasePoint)
    }
    
    func update(currentTime: TimeInterval, killSound: @escaping (TimeInterval) -> ()) {
        if didRelease {
            if vibrationOn {
                let dissipationFactor: CGFloat = 1.2
                let timeOffset = abs(releasePoint.y) / velocity
                let intensity = sin(.pi * (currentTime - releaseTime - timeOffset) * 5) * (1 - (currentTime - releaseTime - timeOffset) / dissipationFactor)
                if (1 - (currentTime - releaseTime - timeOffset) / dissipationFactor) < 0.4 && soundOn {
                    soundOn = false
                    killSound(currentTime)
                }
                if (1 - (currentTime - releaseTime - timeOffset) / dissipationFactor) < 0 {
                    didRelease = false
                    vibrationOn = false
                }
                vibrate(intensity: intensity)
            } else {
                checkVibrationStart(currentTime: currentTime)
            }
        }
    }
    
    func vibrate(intensity: CGFloat) {
        let path = UIBezierPath()
        path.move(to: startPoint)
        for angle in stride(from: 0.0, through: 360.0, by: 5.0) {
            let x = startPoint.x + CGFloat(angle/360) * (endPoint.x - startPoint.x)
            let y = startPoint.y - intensity * CGFloat(sin(.pi * angle / 360)) * 300 * releasePoint.y / abs(releasePoint.y)
            path.addLine(to: CGPoint(x: x, y: y))
        }
        waveNode.path = path.cgPath
    }
}
