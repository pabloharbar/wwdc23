//
//  File.swift
//  
//
//  Created by Pablo Penas on 08/04/23.
//

import Foundation

class StringSound {
    let baseFrequency: Float = 130.81
    private var harmonicConfig: HarmonicConfig
    private var frequencyFraction: Float = 1
    var synth = Synth(baseFrequency: 130.81)
    
    init() {
        self.harmonicConfig = HarmonicConfig(first: 1.0, second: 0.301, third: 0.177, fourth: 0.114, fifth: 0.092)
    }
    
    
    func playSound(currentTime: TimeInterval) {
        synth.playNote(currentTime: currentTime)
    }
    
    func updateInstrument(instrument: Instruments) {
        switch instrument {
        case .guitar:
            self.harmonicConfig = HarmonicConfig(first: 1.0, second: 0.301, third: 0.177, fourth: 0.114, fifth: 0.092)
        case .piano:
            self.harmonicConfig = HarmonicConfig(first: 0, second: 1, third: 0.5, fourth: 0.3)
        }
        synth.updateHarmonicConfig(config: harmonicConfig)
    }
    
    func updateFrequency(baseFrequencyFraction: Float) {
        self.synth.updateFrequency(frequency: baseFrequency * baseFrequencyFraction)
    }
    
    func stopSound(currentTime: TimeInterval) {
        synth.stopNote(currentTime: currentTime)
    }
}
