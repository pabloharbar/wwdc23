//
//  File.swift
//  
//
//  Created by Pablo Penas on 08/04/23.
//

import SpriteKit

enum Instruments {
    case guitar
    case piano
}

class StringScene: SKScene {
    var character = SKSpriteNode()
    var speechBubble = SKShapeNode()
    var speechText = SKLabelNode(text: "")
    var stringSceneManager = StringSceneManager()
    var freeze = true
    var currentInstrument = Instruments.guitar
    var finishAct: () -> () = {}
    var interactingWithString = false
    var lock = false
    var interactingWithStartPoint = false
    var frequencyFraction: Float = 1
    
    var finishButton = SKNode()
    
    private var stringSoundManager = StringSound()
    var lastUpdate = TimeInterval(0)
    private let baseFrequency: CGFloat = 86.0 // C3
    private var stringStart = SKShapeNode(circleOfRadius: 40)
    private var stringEnd = SKShapeNode(circleOfRadius: 40)
    private var stringWave = StringWave(start: CGPoint(x: -750, y: 0), end: CGPoint(x: 750, y: 0))
    private var instrumentSwitch = SKNode()
    
    override func didMove(to view: SKView) {
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        
        stringStart.position = CGPoint(x: -750, y: 0)
        stringStart.zPosition = 10
        stringStart.fillColor = .white
        stringEnd.position = CGPoint(x: 750, y: 0)
        stringEnd.zPosition = 10
        stringEnd.fillColor = .white
        stringWave = StringWave(start: stringStart.position, end: stringEnd.position)
        
        character = SKSpriteNode(texture: SKTexture(image: UIImage(named: "speechCharacter1")!))
        character.position = CGPoint(x: -700, y: 450)
        character.zPosition = 11
        
        speechBubble = SKShapeNode(rect: CGRect(x: -800, y: 360, width: 1600, height: 180), cornerRadius: 20)
        speechBubble.strokeColor = UIColor(named: "BorderColor")!
        speechBubble.fillColor = UIColor(named: "DialogBackground")!
        speechBubble.zPosition = 10
        
        speechText.text = stringSceneManager.currentSpeech
        speechText.fontName = "SF Pro Rounded"
        speechText.fontSize = 48
        speechText.numberOfLines = -1
        speechText.preferredMaxLayoutWidth = 1350
        speechText.horizontalAlignmentMode = .left
        speechText.verticalAlignmentMode = .top
        speechText.position = CGPoint(x: -600, y: 512)
        speechText.zPosition = 11
        speechText.startTyping(TimeInterval(0.01), completion: {self.freeze = false})
        
        instrumentSwitch.position = CGPoint(x: 700, y: -400)
        instrumentSwitch.zPosition = 1
        
        let buttonBackground = SKShapeNode(rect: CGRect(x: -850, y: -480, width: 300, height: 90), cornerRadius: 20)
        buttonBackground.fillColor = UIColor(named: "BorderColor")!
        buttonBackground.strokeColor = UIColor(named: "DialogBackground")!
        buttonBackground.zPosition = 10
        
        let buttonText = SKLabelNode(text: "Tell me more!")
        buttonText.fontName = "SF Pro Rounded"
        buttonText.fontColor = UIColor(named: "DialogBackground")!
        buttonText.position = CGPoint(x: -700, y: -450)
        buttonText.fontSize = 40
        buttonText.zPosition = 11
        
        finishButton.addChild(buttonBackground)
        finishButton.addChild(buttonText)
        
        self.addChild(character)
        self.addChild(speechBubble)
        self.addChild(speechText)
        
        self.addChild(stringStart)
        self.addChild(stringEnd)
        self.addChild(stringWave.waveNode)
        self.addChild(instrumentSwitch)
    }
    
    func createInstrumentSwitch(backgroundColor: UIColor = .black) {
        instrumentSwitch.removeAllChildren()
        let background = SKShapeNode(rect: CGRect(x: -71, y: -66, width: 142, height: 132), cornerRadius: 20)
        background.fillColor = backgroundColor
        background.strokeColor = UIColor(named: "BorderColor")!
        background.lineWidth = 5
        background.zPosition = 1
        
//        let config = UIImage.SymbolConfiguration(pointSize: 80)
//        let image = UIImage(systemName: currentInstrument == .guitar ? "pianokeys.inverse" : "guitars.fill", withConfiguration: config)!.withTintColor(UIColor.white)
//        let data = image.pngData()
//        let newImage = UIImage(data:data!)
//        let texture = SKTexture(image: newImage!)
        let image = UIImage(named: currentInstrument == .guitar ? "acousticGuitarIcon" : "electricGuitarIcon")!
        let texture = SKTexture(image: image)
        let instrumentImage = SKSpriteNode(texture: texture, size: CGSize(width: 106, height: 96))
        instrumentImage.zPosition = 2
        instrumentSwitch.addChild(background)
        instrumentSwitch.addChild(instrumentImage)
    }
    
    func touchDown(at pos: CGPoint) {
        if instrumentSwitch.contains(pos) && !interactingWithString {
            instrumentSwitch.removeAllActions()
            switch currentInstrument {
            case .guitar:
                stringWave.waveNode.strokeColor = UIColor(named: "Note6")!
                currentInstrument = .piano
                createInstrumentSwitch()
            case .piano:
                stringWave.waveNode.strokeColor = UIColor(named: "NeonGreen")!
                currentInstrument = .guitar
                createInstrumentSwitch()
            }
            stringSoundManager.updateInstrument(instrument: currentInstrument)
        } else if stringStart.contains(pos) && stringSceneManager.currentSpeechIndex >= 4 {
            interactingWithStartPoint = true
            interactingWithString = false
        } else if finishButton.contains(pos) {
            lock = true
            stringSoundManager.stopSound(currentTime: lastUpdate)
            finishAct()
        } else if !interactingWithString && !lock {
            interactingWithString = true
            interactWithString(at: pos)
        }
    }
    
    func touchMoved(at pos: CGPoint) {
        if !instrumentSwitch.contains(pos) && interactingWithString && !interactingWithStartPoint {
            interactWithString(at: pos)
        } else if interactingWithStartPoint {
            stringStart.position.x = pos.x >= -750 && pos.x <= 100 ? pos.x : stringStart.position.x
            stringWave.updateWaveStartPoint(position: stringStart.position) { fraction in
                self.frequencyFraction = fraction
//                stringSoundManager.updateFrequency(baseFrequencyFraction: fraction)
            }
        }
    }
    
    func interactWithString(at pos: CGPoint) {
        if self.stringWave.vibrationOn {
            self.stringWave.stopString()
        }
        self.stringWave.dragString(pos: pos)
    }
    
    func advanceText() {
        freeze = true
        let old_index = stringSceneManager.currentSpeechIndex
        stringSceneManager.advanceSpeech(sprite: character)
        let new_index = stringSceneManager.currentSpeechIndex
        if new_index == 1 {
            // Piscar instrument switch
            let glow = SKAction.customAction(withDuration: 0.5, actionBlock: {_,_ in
                self.createInstrumentSwitch(backgroundColor: UIColor(red: 0.4, green: 0, blue: 0, alpha: 1))
            })
            let unglow = SKAction.customAction(withDuration: 0.5, actionBlock: {_,_ in
                self.createInstrumentSwitch(backgroundColor: .black)
            })
            instrumentSwitch.run(SKAction.repeatForever(SKAction.sequence([glow, unglow])))
        }
        speechText.text = stringSceneManager.currentSpeech
        if new_index != old_index {
            if new_index == 4  {
                // Piscar no da corda
                let glow = SKAction.customAction(withDuration: 0.3, actionBlock: {_,_ in
                    self.stringStart.fillColor = UIColor(red: 1, green: 0.7, blue: 0.7, alpha: 1)
                })
                let unglow = SKAction.customAction(withDuration: 0.3, actionBlock: {_,_ in
                    self.stringStart.fillColor = .white
                })
                stringStart.run(SKAction.repeatForever(SKAction.sequence([glow, unglow])))
            }
            speechText.startTyping(TimeInterval(0.01), completion: {
                self.run(SKAction.wait(forDuration: 2)) {
                    self.freeze = false
                }
            })
        }
    }
    
    func touchUp(at pos: CGPoint) {
        if interactingWithString && !lock {
            if stringSceneManager.currentSpeechIndex == stringSceneManager.speechBank.stringScene1Speeches.count - 1 && stringStart.position.x != -750 {
                if self.finishButton.parent == nil {
                    self.addChild(finishButton)
                }
            }
            self.stringWave.releaseString(releasePoint: pos, currentTime: lastUpdate)
            interactingWithString = false
            self.stringSoundManager.playSound(currentTime: lastUpdate)
            if !freeze {
                if stringSceneManager.currentSpeechIndex == 0 {
                    advanceText()
                    createInstrumentSwitch()
                } else if stringSceneManager.currentSpeechIndex == 1 && currentInstrument == .piano {
                    advanceText()
                } else if stringSceneManager.currentSpeechIndex > 1 {
                    advanceText()
                }
            }
        } else if interactingWithStartPoint && !lock {
            interactingWithStartPoint = false
            stringSoundManager.updateFrequency(baseFrequencyFraction: self.frequencyFraction)
        }
    }
    
 
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchMoved(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchUp(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if lastUpdate == 0 {
            lastUpdate = currentTime
            return
        }
        
//        let deltaTime = currentTime - lastUpdate
        lastUpdate = currentTime
        self.stringWave.update(currentTime: currentTime, killSound: stringSoundManager.stopSound)
        self.stringSoundManager.synth.update(currentTime: lastUpdate)
    }
}
