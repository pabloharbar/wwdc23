//
//  File.swift
//  
//
//  Created by Pablo Penas on 14/04/23.
//

import Foundation
import SpriteKit

class HarmonicStringSceneManager {
    let speechBank = SpeechBank.shared
    var currentSpeech: String
    var currentSpeechIndex: Int = 0
    var currentHarmonicWaveConfig = HarmonicWaveConfig()
    var combineHarmonics = false
    
    init() {
        self.currentSpeech = speechBank.harmonicSceneSpeeches[currentSpeechIndex]
    }
    
    func advanceSpeech(sprite: SKSpriteNode) {
        if currentSpeechIndex < speechBank.harmonicSceneSpeeches.count - 1 {
            currentSpeechIndex += 1
            self.currentSpeech = speechBank.harmonicSceneSpeeches[currentSpeechIndex]
            advanceFrame(sprite: sprite)
        }
    }
    
    func advanceFrame(sprite: SKSpriteNode) {
        if currentSpeechIndex < speechBank.harmonicSceneImages.count {
            let image = UIImage(named: speechBank.harmonicSceneImages[currentSpeechIndex])!
            let texture = SKTexture(image: image)
            if currentSpeechIndex == 1 {
                sprite.size = image.size
                sprite.position = CGPoint(x: -700, y: 450)
            }
            sprite.run(SKAction.setTexture(texture))
        }
    }
    
    func updateHarmonicWaveConfig(config: HarmonicWaveConfig) {
        currentHarmonicWaveConfig = config
    }
}
