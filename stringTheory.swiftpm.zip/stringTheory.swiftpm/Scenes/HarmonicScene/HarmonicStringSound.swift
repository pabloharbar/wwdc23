//
//  File.swift
//  
//
//  Created by Pablo Penas on 14/04/23.
//

import Foundation
//import AudioKit

class HarmonicStringSound {
    let baseFrequency: Float = 130.81
    private var harmonicConfig: HarmonicConfig
    var synth: Synth
    
    init() {
//        let harmonicConfig = HarmonicConfig(first: 1.0, second: 0.301, third: 0.177, fourth: 0.114, fifth: 0.092)
        self.harmonicConfig = HarmonicConfig(first: 0.8, second: 0.5, third: 0.1)
        self.synth = Synth(baseFrequency: baseFrequency)
    }
    
    
    func playSound(currentTime: TimeInterval) {
        synth.playNote(currentTime: currentTime)
    }
    
    func updateVolume(_ amplitude: Float) {
    }
    
    func updateFrequency(baseFrequencyFraction: Float) {
        self.synth.updateFrequency(frequency: baseFrequency * baseFrequencyFraction)
    }
    
    func stopSound(currentTime: TimeInterval) {
        synth.stopNote(currentTime: currentTime)
    }
}
