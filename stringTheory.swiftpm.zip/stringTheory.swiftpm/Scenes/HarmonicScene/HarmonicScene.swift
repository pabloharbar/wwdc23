//
//  File.swift
//  
//
//  Created by Pablo Penas on 14/04/23.
//

import SpriteKit

class HarmonicScene: SKScene {
    var character = SKSpriteNode()
    var backgroundImage = SKSpriteNode()
    var speechBubble = SKShapeNode()
    var speechText = SKLabelNode(text: "")
    var stringSceneManager = HarmonicStringSceneManager()
    var freeze = true
//    var currentInstrument = Instruments.guitar
    var finishAct: () -> () = {}
    var interactingWithString = false
    var interactingWithStartPoint = false
    var frequencyFraction: Float = 1
    
    var finishButton = SKNode()
    
    var firstSwitch = SKShapeNode()
    var secondSwitch = SKShapeNode()
    var thirdSwitch = SKShapeNode()
    var fourthSwitch = SKShapeNode()
    var combineSwitch = SKShapeNode()
    var combineLabel = SKLabelNode()
    
    private var stringSoundManager = HarmonicStringSound()
    var lastUpdate = TimeInterval(0)
    private let baseFrequency: CGFloat = 86.0 // C3
    private var stringStart = SKShapeNode(circleOfRadius: 40)
    private var stringEnd = SKShapeNode(circleOfRadius: 40)
    private var stringWave = HarmonicStringWave(start: CGPoint(x: -750, y: 0), end: CGPoint(x: 750, y: 0))
//    private var instrumentSwitch = SKNode()
    private var stringEnabled = false
    var lock = false
    
    override func didMove(to view: SKView) {
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        
        backgroundImage = SKSpriteNode(texture: SKTexture(image: UIImage(named: "studioBackground")!.alpha(1.0)))
        backgroundImage.size = self.size
        backgroundImage.position = CGPoint(x: 0, y: 0)
        backgroundImage.zPosition = -1
        
        stringStart.position = CGPoint(x: -750, y: 0)
        stringStart.zPosition = 11
        stringStart.fillColor = .white
        stringEnd.position = CGPoint(x: 750, y: 0)
        stringEnd.zPosition = 11
        stringEnd.fillColor = .white
        stringWave = HarmonicStringWave(start: stringStart.position, end: stringEnd.position)
        
        character = SKSpriteNode(texture: SKTexture(image: UIImage(named: "characterPosition3")!))
//        character.position = CGPoint(x: -700, y: 450)
        character.position = CGPoint(x: 200, y: -300)
        character.zPosition = 11
        
        speechBubble = SKShapeNode(rect: CGRect(x: -800, y: 360, width: 1600, height: 180), cornerRadius: 20)
        speechBubble.strokeColor = UIColor(named: "BorderColor")!
        speechBubble.fillColor = UIColor(named: "DialogBackground")!
        speechBubble.zPosition = 10
        
        speechText.text = stringSceneManager.currentSpeech
        speechText.fontName = "SF Pro Rounded"
        speechText.fontSize = 48
        speechText.numberOfLines = -1
//        speechText.preferredMaxLayoutWidth = 1350
        speechText.preferredMaxLayoutWidth = 1500
        speechText.horizontalAlignmentMode = .left
        speechText.verticalAlignmentMode = .top
//        speechText.position = CGPoint(x: -600, y: 512)
        speechText.position = CGPoint(x: -750, y: 512)
        speechText.zPosition = 11
        speechText.startTyping(TimeInterval(0.01), completion: {
            self.run(SKAction.wait(forDuration: 1)) {
                self.freeze = false
            }
        })
        
        let buttonBackground = SKShapeNode(rect: CGRect(x: -825, y: -480, width: 160, height: 90), cornerRadius: 20)
        buttonBackground.fillColor = UIColor(named: "BorderColor")!
        buttonBackground.strokeColor = UIColor(named: "DialogBackground")!
        buttonBackground.zPosition = 10
        
        let buttonText = SKLabelNode(text: "Got it!")
        buttonText.fontName = "SF Pro Rounded"
        buttonText.fontColor = UIColor(named: "DialogBackground")!
        buttonText.position = CGPoint(x: -750, y: -450)
        buttonText.fontSize = 40
        buttonText.zPosition = 11
        
        finishButton.addChild(buttonBackground)
        finishButton.addChild(buttonText)
        
        self.addChild(character)
        self.addChild(speechBubble)
        self.addChild(speechText)
        self.addChild(backgroundImage)
        
    }
    
//    func createHarmonicSwitches(harmonicConfig: HarmonicWaveConfig) {
    func createHarmonicSwitches() {
        let firstLabel = SKLabelNode(text: "1st")
        firstLabel.fontName = "SF Pro Rounded"
        firstLabel.fontColor = .white
        firstLabel.position = CGPoint(x: -400, y: -515)
        firstLabel.fontSize = 40
        firstLabel.zPosition = 11
        firstSwitch = SKShapeNode(rect: CGRect(x: -450, y: -550, width: 100, height: 100), cornerRadius: 20)
//        firstSwitch.strokeColor = UIColor(named: "BorderColor")!
//        firstSwitch.fillColor = UIColor(named: "DialogBackground")!
        firstSwitch.fillColor = UIColor(named: "Note0")!.withAlphaComponent(0.7)
        firstSwitch.zPosition = 10
        firstSwitch.addChild(firstLabel)
        
        let secondLabel = SKLabelNode(text: "2nd")
        secondLabel.fontName = "SF Pro Rounded"
        secondLabel.fontColor = .white
        secondLabel.position = CGPoint(x: -150, y: -515)
        secondLabel.fontSize = 40
        secondLabel.zPosition = 11
        secondSwitch = SKShapeNode(rect: CGRect(x: -200, y: -550, width: 100, height: 100), cornerRadius: 20)
        secondSwitch.fillColor = UIColor(named: "Note5")!.withAlphaComponent(0.7)
        secondSwitch.zPosition = 10
        secondSwitch.addChild(secondLabel)
        
        let thirdLabel = SKLabelNode(text: "3rd")
        thirdLabel.fontName = "SF Pro Rounded"
        thirdLabel.fontColor = .white
        thirdLabel.position = CGPoint(x: 100, y: -515)
        thirdLabel.fontSize = 40
        thirdLabel.zPosition = 11
        thirdSwitch = SKShapeNode(rect: CGRect(x: 50, y: -550, width: 100, height: 100), cornerRadius: 20)
        thirdSwitch.fillColor = UIColor(named: "Note8")!
        thirdSwitch.zPosition = 10
        thirdSwitch.addChild(thirdLabel)
        
        let fourthLabel = SKLabelNode(text: "4th")
        fourthLabel.fontName = "SF Pro Rounded"
        fourthLabel.fontColor = .white
        fourthLabel.position = CGPoint(x: 350, y: -515)
        fourthLabel.fontSize = 40
        fourthLabel.zPosition = 11
        fourthSwitch = SKShapeNode(rect: CGRect(x: 300, y: -550, width: 100, height: 100), cornerRadius: 20)
        fourthSwitch.fillColor = UIColor(named: "Note11")!.withAlphaComponent(0.7)
        fourthSwitch.zPosition = 10
        fourthSwitch.addChild(fourthLabel)
        
        combineLabel = SKLabelNode(text: "Combine")
        combineLabel.fontName = "SF Pro Rounded"
        combineLabel.fontColor = .white
        combineLabel.position = CGPoint(x: 650, y: -515)
        combineLabel.fontSize = 40
        combineLabel.zPosition = 11
        combineSwitch = SKShapeNode(rect: CGRect(x: 550, y: -550, width: 200, height: 100), cornerRadius: 20)
        combineSwitch.strokeColor = UIColor(named: "BorderColor")!
        combineSwitch.fillColor = UIColor(named: "DialogBackground")!
        combineSwitch.zPosition = 10
        combineSwitch.addChild(combineLabel)
        
        self.addChild(combineSwitch)
        
        self.addChild(firstSwitch)
        self.addChild(secondSwitch)
        self.addChild(thirdSwitch)
        self.addChild(fourthSwitch)
    }
    
    func updateHarmonicSwitches() {
        if stringSceneManager.currentHarmonicWaveConfig.firstOn {
            firstSwitch.fillColor = UIColor(named: "NeonGreen")!.withAlphaComponent(0.7)
            firstSwitch.strokeColor = UIColor(named: "NeonGreen")!.withAlphaComponent(0.7)
        } else {
            firstSwitch.strokeColor = UIColor(named: "BorderColor")!
            firstSwitch.fillColor = UIColor(named: "DialogBackground")!
        }
        if stringSceneManager.currentHarmonicWaveConfig.secondOn {
            secondSwitch.fillColor = UIColor(named: "Note5")!.withAlphaComponent(0.7)
            secondSwitch.strokeColor = UIColor(named: "Note5")!.withAlphaComponent(0.7)
        } else {
            secondSwitch.strokeColor = UIColor(named: "BorderColor")!
            secondSwitch.fillColor = UIColor(named: "DialogBackground")!
        }
        if stringSceneManager.currentHarmonicWaveConfig.thirdOn {
            thirdSwitch.fillColor = UIColor(named: "Note8")!.withAlphaComponent(0.7)
            thirdSwitch.strokeColor = UIColor(named: "Note8")!.withAlphaComponent(0.7)
        } else {
            thirdSwitch.strokeColor = UIColor(named: "BorderColor")!
            thirdSwitch.fillColor = UIColor(named: "DialogBackground")!
        }
        if stringSceneManager.currentHarmonicWaveConfig.fourthOn {
            fourthSwitch.fillColor = UIColor(named: "Note11")!.withAlphaComponent(0.7)
            fourthSwitch.strokeColor = UIColor(named: "Note11")!.withAlphaComponent(0.7)
        } else {
            fourthSwitch.strokeColor = UIColor(named: "BorderColor")!
            fourthSwitch.fillColor = UIColor(named: "DialogBackground")!
        }
        if stringSceneManager.combineHarmonics {
            combineSwitch.strokeColor = UIColor(named: "BorderColor")!
            combineSwitch.fillColor = .white
            combineLabel.fontColor = .black
        } else {
            combineSwitch.strokeColor = UIColor(named: "BorderColor")!
            combineSwitch.fillColor = UIColor(named: "DialogBackground")!
            combineLabel.fontColor = .white
        }
    }
    
    func touchDown(at pos: CGPoint) {
        if finishButton.contains(pos) {
            lock = true
            self.stringSoundManager.stopSound(currentTime: lastUpdate)
            self.finishAct()
        } else if stringEnabled && !lock {
            if firstSwitch.contains(pos) {
                var config = stringSceneManager.currentHarmonicWaveConfig
                config.firstOn.toggle()
                stringSceneManager.updateHarmonicWaveConfig(config: config)
                updateHarmonicSwitches()
            } else if secondSwitch.contains(pos) {
                var config = stringSceneManager.currentHarmonicWaveConfig
                config.secondOn.toggle()
                stringSceneManager.updateHarmonicWaveConfig(config: config)
                updateHarmonicSwitches()
            } else if thirdSwitch.contains(pos) {
                var config = stringSceneManager.currentHarmonicWaveConfig
                config.thirdOn.toggle()
                stringSceneManager.updateHarmonicWaveConfig(config: config)
                updateHarmonicSwitches()
            } else if fourthSwitch.contains(pos) {
                var config = stringSceneManager.currentHarmonicWaveConfig
                config.fourthOn.toggle()
                stringSceneManager.updateHarmonicWaveConfig(config: config)
                updateHarmonicSwitches()
            } else if combineSwitch.contains(pos) {
                stringSceneManager.combineHarmonics.toggle()
                updateHarmonicSwitches()
            } else if stringStart.contains(pos) {
                interactingWithStartPoint = true
                interactingWithString = false
            } else if !interactingWithStartPoint {
                interactingWithString = true
                interactWithString(at: pos)
            }
        } else if !freeze && !lock {
            freeze = true
            character.run(SKAction.fadeOut(withDuration: 0.2))
            backgroundImage.run(SKAction.fadeOut(withDuration: 0.6)) {
                self.stringEnabled = true
                self.character.run(SKAction.fadeIn(withDuration: 0.2))
                self.speechText.preferredMaxLayoutWidth = 1350
                self.speechText.position = CGPoint(x: -600, y: 512)
                self.advanceText()
                self.addChild(self.stringStart)
                self.addChild(self.stringEnd)
                self.addChild(self.stringWave.waveNode)
                self.createHarmonicSwitches()
            }
        }
    }
    
    func touchMoved(at pos: CGPoint) {
        if stringEnabled && !lock {
            if interactingWithString && !interactingWithStartPoint {
                interactWithString(at: pos)
            } else if interactingWithStartPoint {
                stringStart.position.x = pos.x >= -750 && pos.x <= 100 ? pos.x : stringStart.position.x
                stringWave.updateWaveStartPoint(position: stringStart.position) { fraction in
                    self.frequencyFraction = fraction
                    //                stringSoundManager.updateFrequency(baseFrequencyFraction: fraction)
                }
            }
        }
    }
    
    func interactWithString(at pos: CGPoint) {
        if self.stringWave.vibrationOn {
            self.stringWave.stopString()
        }
        self.stringWave.dragString(pos: pos)
    }
    
    func advanceText() {
        freeze = true
        let old_index = stringSceneManager.currentSpeechIndex
        stringSceneManager.advanceSpeech(sprite: character)
        let new_index = stringSceneManager.currentSpeechIndex
        speechText.text = stringSceneManager.currentSpeech
        if new_index != old_index {
            if new_index == 5 {
                stringSceneManager.combineHarmonics = true
                updateHarmonicSwitches()
            }
            speechText.startTyping(TimeInterval(0.01), completion: {
                self.run(SKAction.wait(forDuration: 5)) {
                    self.freeze = false
                }
            })
        }
    }
    
    func touchUp(at pos: CGPoint) {
        if stringEnabled && !lock {
            if interactingWithString {
                self.stringWave.releaseString(releasePoint: pos, currentTime: lastUpdate)
                interactingWithString = false
                self.stringSoundManager.playSound(currentTime: lastUpdate)
                if !freeze {
                    advanceText()
                }
            } else if interactingWithStartPoint {
                interactingWithStartPoint = false
                stringSoundManager.updateFrequency(baseFrequencyFraction: self.frequencyFraction)
            }
        }
        if stringSceneManager.currentSpeechIndex == stringSceneManager.speechBank.harmonicSceneSpeeches.count - 1 {
            self.run(SKAction.wait(forDuration: 2)) {
                if self.finishButton.parent == nil {
                    self.addChild(self.finishButton)
                }
            }
        }
    }
    
 
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchMoved(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchUp(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if lastUpdate == 0 {
            lastUpdate = currentTime
            return
        }
        
//        let deltaTime = currentTime - lastUpdate
        lastUpdate = currentTime
        self.stringWave.update(currentTime: currentTime, harmonicConfig: stringSceneManager.currentHarmonicWaveConfig, combineHarmonics: stringSceneManager.combineHarmonics, killSound: stringSoundManager.stopSound, updateVolume: stringSoundManager.updateVolume)
        self.stringSoundManager.synth.update(currentTime: lastUpdate)
    }
}
