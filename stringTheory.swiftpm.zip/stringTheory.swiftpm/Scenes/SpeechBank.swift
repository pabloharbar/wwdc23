//
//  File.swift
//  
//
//  Created by Pablo Penas on 12/04/23.
//

import Foundation

class SpeechBank {
    static let shared = SpeechBank()
    
    let studioScene1Speeches = [
        "Hello friend, you seem to be curious of what I am doing",
        "I am trying to figure out why my acoustic guitar sounds different than my electric guitar, even when I play the same note!",
        "If you don’t believe me, then give it a try...",
    ]
    let studioScene1Images = [
        "characterPosition1",
        "characterPosition2",
        "characterPosition3",
        "characterPosition4",
    ]
    
    let stringScene1Speeches = [
        "Play a note in the acoustic guitar dragging and releasing the string",
        "Cool, right? Now you should try in the electric guitar, press the button to switch instruments",
        "Can you notice? They really sound different!",
        "Both are string instruments, which means that they produce sound whenever its strings vibrate",
        "The frequency of a sound equals to the inverse of its wave length",
        "We can change the note, or the frequency, by changing how long the strings are. Try it!",
    ]
    let stringScene1Images = [
        "speechCharacter1",
        "speechCharacter2",
        "speechCharacter3",
        "speechCharacter1",
        "speechCharacter4",
    ]
    
    let harmonicSceneSpeeches = [
        "You were seeing only one mode of vibration...",
        "When a string vibrates it also vibrates in different frequencies, which we call harmonics",
        "These frequencies are excited based on the fundamental frequency or simply the 1st harmonic",
        "And they are also multiple of the fundamental frequency!",
        "The 2nd harmonic has double the fundamental frequency, the 3rd has triple and so on...",
        "In reality when we play an instrument all of these frequencies add up",
    ]
    let harmonicSceneImages = [
        "characterPosition4",
        "speechCharacter3",
        "speechCharacter4",
        "speechCharacter1",
        "speechCharacter4",
        "speechCharacter1",
    ]
    let ReflectionSceneSpeeches = [
        "In a way that the intensity of each harmonic is different...",
        "Aha!",
        "That’s how the sound of each guitar is unique!",
        "It’s called timbre, what and how intense are each harmonic excited when we play a certain note",
        "Now that you helped me answer my question, I’ll let you try my experimental instrument"
    ]
    let ReflectionSceneImages = [
        "characterPosition4",
        "characterPosition2",
        "characterPosition1",
        "characterPosition5",
        "characterPosition3",
    ]
}
