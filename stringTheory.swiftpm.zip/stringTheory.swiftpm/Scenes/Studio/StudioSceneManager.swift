//
//  File.swift
//  
//
//  Created by Pablo Penas on 12/04/23.
//

import SpriteKit

class StudioSceneManager {
    let speechBank = SpeechBank.shared
    var currentSpeech: String
    var currentSpeechIndex: Int = 0
    
    init() {
        self.currentSpeech = speechBank.studioScene1Speeches[currentSpeechIndex]
    }
    
    func advanceSpeech(sprite: SKSpriteNode, background: SKSpriteNode, addGuitarNodeToScene: @escaping () -> ()) {
        if currentSpeechIndex < speechBank.studioScene1Speeches.count - 1 {
            currentSpeechIndex += 1
            self.currentSpeech = speechBank.studioScene1Speeches[currentSpeechIndex]
            advanceFrame(sprite: sprite, background: background)
            if currentSpeechIndex == 2 {
                sprite.run(SKAction.move(to: CGPoint(x: 100, y: -290), duration: 0.5)) {
                    addGuitarNodeToScene()
                }
            }
        }
    }
    
    func advanceFrame(sprite: SKSpriteNode, background: SKSpriteNode) {
        if currentSpeechIndex < speechBank.studioScene1Speeches.count {
            let texture = SKTexture(image: UIImage(named: speechBank.studioScene1Images[currentSpeechIndex])!)
            sprite.run(SKAction.setTexture(texture))
        }
    }
    
    func returnSpeech() {
        
    }
}
