//
//  File.swift
//  
//
//  Created by Pablo Penas on 10/04/23.
//

import SpriteKit


class StudioScene: SKScene {
    var character = SKSpriteNode()
    var background = SKSpriteNode()
    var speechBubble = SKShapeNode()
    var guitarNode = SKSpriteNode()
    var shadow = SKShapeNode()
    var speechText = SKLabelNode(text: "")
    var studioSceneManager = StudioSceneManager()
    var freeze = true
    var finishAct: () -> () = {}
    
    override func didMove(to view: SKView) {
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.backgroundColor = UIColor.black
        
        character = SKSpriteNode(texture: SKTexture(image: UIImage(named: "characterPosition1")!))
        character.position = CGPoint(x: 80, y: -280)
        character.zPosition = 0
        
        background = SKSpriteNode(texture: SKTexture(image: UIImage(named: "studioBackground")!.alpha(1.0)))
        background.size = self.size
        background.position = CGPoint(x: 0, y: 0)
        background.zPosition = -1
        
        speechBubble = SKShapeNode(rect: CGRect(x: -800, y: 360, width: 1600, height: 180), cornerRadius: 20)
        speechBubble.strokeColor = UIColor(named: "BorderColor")!
        speechBubble.fillColor = UIColor(named: "DialogBackground")!
        speechBubble.zPosition = 10
        
        speechText.text = studioSceneManager.currentSpeech
        speechText.fontName = "SF Pro Rounded"
        speechText.fontSize = 48
        speechText.numberOfLines = -1
        speechText.preferredMaxLayoutWidth = 1500
        speechText.horizontalAlignmentMode = .left
        speechText.verticalAlignmentMode = .top
        speechText.position = CGPoint(x: -750, y: 512)
        speechText.zPosition = 11
        speechText.startTyping(TimeInterval(0.01), completion: {self.freeze = false})

        
        
        self.addChild(character)
        self.addChild(background)
        self.addChild(speechBubble)
        self.addChild(speechText)
    }
    
    func touchDown(at pos: CGPoint) {
        if !freeze {
            advanceText()
        }
        if guitarNode.contains(pos) {
            finishAct()
        }
    }
    
    func advanceText() {
        freeze = true
        let old_index = studioSceneManager.currentSpeechIndex
        studioSceneManager.advanceSpeech(sprite: character, background: background) {
            self.guitarNode = SKSpriteNode(texture: SKTexture(imageNamed: "guitar"))
            self.guitarNode.zPosition = 10
            self.guitarNode.position = CGPoint(x: 130, y: -365)
            self.addChild(self.guitarNode)
            self.shadow = SKShapeNode(rect: self.frame)
            self.shadow.zPosition = 3
            self.shadow.fillColor = .black.withAlphaComponent(0.8)
            self.addChild(self.shadow)
        }
        let new_index = studioSceneManager.currentSpeechIndex
        speechText.text = studioSceneManager.currentSpeech
        if old_index != new_index {
            speechText.startTyping(TimeInterval(0.01), completion: {
                self.run(SKAction.wait(forDuration: 1)) {
                    self.freeze = false
                }
            })
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
    
}
