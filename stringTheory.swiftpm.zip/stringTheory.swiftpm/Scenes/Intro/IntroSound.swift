//
//  File.swift
//  
//
//  Created by Pablo Penas on 17/04/23.
//

import AVFoundation

class IntroSound {
    var introSoundPlayer: AVAudioPlayer?
    var doorSoundPlayer: AVAudioPlayer?
//
    static var shared = IntroSound()
    
    func playIntroSound() {
        guard let url = Bundle.main.url(forResource: "introSound", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            introSoundPlayer = try AVAudioPlayer(contentsOf: url)
            introSoundPlayer?.volume = 0.4
            DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
                self.introSoundPlayer?.setVolume(0, fadeDuration: 1.1)
            }
            introSoundPlayer?.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func playDoorSound() {
        guard let url = Bundle.main.url(forResource: "doorSound", withExtension: "wav") else { return }
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            doorSoundPlayer = try AVAudioPlayer(contentsOf: url)
            doorSoundPlayer?.volume = 0.2
            doorSoundPlayer?.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
