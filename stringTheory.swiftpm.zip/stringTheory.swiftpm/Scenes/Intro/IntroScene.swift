//
//  File.swift
//  
//
//  Created by Pablo Penas on 12/04/23.
//

import SpriteKit

class IntroScene: SKScene {
    var entranceNode = SKSpriteNode()
    var doorNode = SKSpriteNode()
    var finishAct: () -> () = {}
    var backgroundNode = SKSpriteNode()
    var lightNode = SKShapeNode()
    
    var freeze = false
    
    override func didMove(to view: SKView) {
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        backgroundNode = SKSpriteNode(texture: SKTexture(image: UIImage(named: "cover")!))
        backgroundNode.alpha = 0
        backgroundNode.size = self.size
        backgroundNode.position = CGPoint(x: 0, y: 0)
        backgroundNode.zPosition = -1
        
        let image  = UIImage(named: "entranceMask")!.alpha(1.0)
        entranceNode = SKSpriteNode(texture: SKTexture(image: image))
        entranceNode.size = self.size
        entranceNode.position = CGPoint(x: 0, y: 0)
        entranceNode.zPosition = 1
        
        let scaleX = entranceNode.size.width / image.size.width
        let scaleY = entranceNode.size.height / image.size.height
        doorNode = SKSpriteNode(texture: SKTexture(image: UIImage(named: "door")!.alpha(1.0)))
        doorNode.xScale = scaleX
        doorNode.yScale = scaleY
        doorNode.position = CGPoint(x: 0, y: -70)
        doorNode.zPosition = 0
        
        self.addChild(backgroundNode)
        self.addChild(entranceNode)
        self.addChild(doorNode)
    }
    
    func touchDown(at pos: CGPoint) {
        if !freeze {
            freeze = true
            let sourcePositions: [SIMD2<Float>] = [
                SIMD2(0, 0),   SIMD2(1, 0),
                SIMD2(0, 1),   SIMD2(1, 1),
            ]
            let destinationPositions: [SIMD2<Float>] = [
                SIMD2(0.5, 0.2),   SIMD2(1, 0),
                SIMD2(0.5, 0.8),   SIMD2(1, 1),
            ]
            let warpGeometryGrid = SKWarpGeometryGrid(columns: 1,
                                                      rows: 1,
                                                      sourcePositions: sourcePositions,
                                                      destinationPositions: destinationPositions)
            doorNode.warpGeometry = SKWarpGeometryGrid(columns: 1, rows: 1)
            doorNode.run(SKAction.warp(to: warpGeometryGrid, duration: 1)!)
//            IntroSound.shared.playDoorSound()
            self.run(SKAction.wait(forDuration: 1)) {
                self.doorNode.run(SKAction.fadeOut(withDuration: 0.5))
                self.entranceNode.run(SKAction.fadeOut(withDuration: 0.5)) {
                    IntroSound.shared.playIntroSound()
                    self.backgroundNode.run(SKAction.fadeIn(withDuration: 2)) {
                        self.run(SKAction.wait(forDuration: 7.5)){
                            self.finishAct()
                        }
                    }
                }
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
}
