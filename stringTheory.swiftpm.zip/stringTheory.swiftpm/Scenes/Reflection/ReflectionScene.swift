//
//  File.swift
//  
//
//  Created by Pablo Penas on 14/04/23.
//

import SpriteKit


class ReflectionScene: SKScene {
    var character = SKSpriteNode()
    var background = SKSpriteNode()
    var speechBubble = SKShapeNode()
    var shadow = SKSpriteNode()
    var speechText = SKLabelNode(text: "")
    var studioSceneManager = ReflectionSceneManager()
    var freeze = true
    var finishAct: () -> () = {}
    
    override func didMove(to view: SKView) {
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.backgroundColor = UIColor.black
        
        character = SKSpriteNode(texture: SKTexture(image: UIImage(named: "characterPosition1")!))
        character.position = CGPoint(x: 80, y: -280)
        character.zPosition = 0
        
        background = SKSpriteNode(texture: SKTexture(image: UIImage(named: "studioBackground")!.alpha(1.0)))
        background.size = self.size
        background.position = CGPoint(x: 0, y: 0)
        background.zPosition = -1
        
        speechBubble = SKShapeNode(rect: CGRect(x: -800, y: 360, width: 1600, height: 180), cornerRadius: 20)
        speechBubble.strokeColor = UIColor(named: "BorderColor")!
        speechBubble.fillColor = UIColor(named: "DialogBackground")!
        speechBubble.zPosition = 10
        
        speechText.text = studioSceneManager.currentSpeech
        speechText.fontName = "SF Pro Rounded"
        speechText.fontSize = 48
        speechText.numberOfLines = -1
        speechText.preferredMaxLayoutWidth = 1500
        speechText.horizontalAlignmentMode = .left
        speechText.verticalAlignmentMode = .top
        speechText.position = CGPoint(x: -750, y: 512)
        speechText.zPosition = 11
        speechText.startTyping(TimeInterval(0.01), completion: {self.freeze = false})

        shadow = SKSpriteNode(texture: SKTexture(image: UIImage(named: "EurekaShadow")!))
        shadow.size = self.size
        shadow.alpha = 0
        shadow.zPosition = 0
        
        self.addChild(shadow)
        self.addChild(character)
        self.addChild(background)
        self.addChild(speechBubble)
        self.addChild(speechText)
    }
    
    func touchDown(at pos: CGPoint) {
        if !freeze {
            if studioSceneManager.currentSpeechIndex == 4 {
                finishAct()
            }
            advanceText()
        }
    }
    
    func advanceText() {
        freeze = true
        let old_index = studioSceneManager.currentSpeechIndex
        studioSceneManager.advanceSpeech(sprite: character)
        let new_index = studioSceneManager.currentSpeechIndex
        speechText.text = studioSceneManager.currentSpeech
        if new_index == 1 {
            shadow.run(SKAction.fadeAlpha(to: 0.7, duration: 0.2))
        }
        if new_index == 2 {
            shadow.run(SKAction.fadeAlpha(to: 0, duration: 0.5))
        }
        if old_index != new_index {
            speechText.startTyping(TimeInterval(0.01), completion: {
                self.run(SKAction.wait(forDuration: 1)) {
                    self.freeze = false
                }
            })
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
    
}
