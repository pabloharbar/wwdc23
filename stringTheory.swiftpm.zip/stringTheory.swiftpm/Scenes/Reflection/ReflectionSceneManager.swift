//
//  File.swift
//
//
//  Created by Pablo Penas on 12/04/23.
//

import SpriteKit

class ReflectionSceneManager {
    let speechBank = SpeechBank.shared
    var currentSpeech: String
    var currentSpeechIndex: Int = 0
    
    init() {
        self.currentSpeech = speechBank.ReflectionSceneSpeeches[currentSpeechIndex]
    }
    
    func advanceSpeech(sprite: SKSpriteNode) {
        if currentSpeechIndex < speechBank.ReflectionSceneSpeeches.count - 1 {
            currentSpeechIndex += 1
            self.currentSpeech = speechBank.ReflectionSceneSpeeches[currentSpeechIndex]
            if currentSpeechIndex == speechBank.ReflectionSceneSpeeches.count - 1 {
                sprite.run(SKAction.move(to: CGPoint(x: 100, y: -290), duration: 0.5))
            }
            advanceFrame(sprite: sprite)
        }
    }
    
    func advanceFrame(sprite: SKSpriteNode) {
        if currentSpeechIndex <= speechBank.ReflectionSceneImages.count - 1 {
            let texture = SKTexture(image: UIImage(named: speechBank.ReflectionSceneImages[currentSpeechIndex])!)
            sprite.run(SKAction.setTexture(texture))
        }
    }

}
