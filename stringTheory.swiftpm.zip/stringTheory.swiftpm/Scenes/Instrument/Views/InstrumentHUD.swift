//
//  SwiftUIView.swift
//  
//
//  Created by Pablo Penas on 09/04/23.
//

import SwiftUI

struct InstrumentHUDView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var harmonicConfig: HarmonicConfig
    var body: some View {
        VStack {
            Button(action: {
                dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                    Spacer()
                }
            }
            .padding(.vertical)
            Spacer()
            List {
                Section(header: Text("Harmonics Intensity")) {
                    HStack {
                        Text("1st")
                        Slider(value: $harmonicConfig.first)
                    }
                    HStack {
                        Text("2st")
                        Slider(value: $harmonicConfig.second)
                    }
                    HStack {
                        Text("3rd")
                        Slider(value: $harmonicConfig.third)
                    }
                    HStack {
                        Text("4th")
                        Slider(value: $harmonicConfig.fourth)
                    }
                    HStack {
                        Text("5th")
                        Slider(value: $harmonicConfig.fifth)
                    }
                }
            }
            .frame(maxWidth: 1000)
            .cornerRadius(20)
            VStack {
                HStack {
                    Text("INSTRUMENT PRESETS")
                        .font(.system(size: 24, design: .rounded))
                        .foregroundColor(.gray)
                    Spacer()
                }
                HStack(spacing: 24) {
                    Button(action: {
                        harmonicConfig = HarmonicConfig(first: 1, second: 0.8, third: 0.5, fourth: 0, fifth: 0)
                        print(harmonicConfig)
                    }) {
                        Image("acousticGuitarIcon")
                            .frame(width: 180, height: 140)
                            .background(Color.black)
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color("BorderColor"), lineWidth: 5)
                            )
                    }
                    Button(action: {
                        harmonicConfig = HarmonicConfig(first: 0, second: 1, third: 0.3, fourth: 0, fifth: 0)
                        print(harmonicConfig)
                    }) {
                        Image("electricGuitarIcon")
                            .font(.system(size: 80))
                            .foregroundColor(.white)
                            .frame(width: 180, height: 140)
                            .background(Color.black)
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color("BorderColor"), lineWidth: 5)
                            )
                    }
                    Button(action: {
                        harmonicConfig = HarmonicConfig(first: 1.0, second: 0.301, third: 0.177, fourth: 0.114, fifth: 0.092)
                        print(harmonicConfig)
                    }) {
                        Image(systemName: "pianokeys.inverse")
                            .font(.system(size: 80))
                            .foregroundColor(.white)
                            .frame(width: 180, height: 140)
                            .background(Color.black)
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color("BorderColor"), lineWidth: 5)
                            )
                    }
                }
                .frame(maxWidth: 1000, maxHeight: 800)
                .cornerRadius(20)
            }
        }
        .padding()
    }
}

struct InstrumentHUDView_Previews: PreviewProvider {
    static var previews: some View {
        InstrumentHUDView(harmonicConfig: .constant(HarmonicConfig()))
    }
}
