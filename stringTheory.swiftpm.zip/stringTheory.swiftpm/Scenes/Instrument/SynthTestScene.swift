//
//  File.swift
//  
//
//  Created by Pablo Penas on 16/04/23.
//

import SpriteKit

class SynthTestScene: SKScene {
    let synth = Synth(baseFrequency: 110)
    var lastUpdate = TimeInterval(0)
    
    func touchDown(at pos: CGPoint) {
        synth.playNote(currentTime: lastUpdate)
    }
    
    func touchUp(at pos: CGPoint) {
        synth.stopNote(currentTime: lastUpdate)
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
//        if lastUpdate == 0 {
//            lastUpdate = currentTime
//            return
//        }
//
//        let deltaTime = currentTime - lastUpdate
        lastUpdate = currentTime
        synth.update(currentTime: lastUpdate)
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchUp(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
    
}
