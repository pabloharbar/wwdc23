//
//  File.swift
//  
//
//  Created by Pablo Penas on 25/03/23.
//

import Foundation
import SpriteKit
//import AudioKit

class OctaveManager {
    let baseFrequency: Float = 130.81
    let notes = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
    private var notesPlaying: [String: Synth] = [:]
    var wavesParentNode = SKNode()
    var wavesSpawned: [Wave] = []
    var harmonicConfig: HarmonicConfig

    init() {
        self.harmonicConfig = HarmonicConfig(first: 1, second: 0.1, third: 0.07, fourth: 0, fifth: 0)
    }

    func emitWave(index: Int, startTime: TimeInterval) {
        if notesPlaying.keys.contains(notes[index]) {
//            mixer.removeInput(notesPlaying[notes[index]]!.envelope)
            notesPlaying[notes[index]]?.shutdownSynth()
            notesPlaying.remove(at: notesPlaying.keys.firstIndex(where: { $0 == notes[index]})!)
        }
        let wave = Wave(parentNode: wavesParentNode, startTime: startTime, index: index)
        let noteFrequency = baseFrequency * pow(2, ((1 + Float(index)) / 12))
        
//        let note = Note(baseNote: noteFrequency, harmonicConfig: harmonicConfig)
        let note = Synth(baseFrequency: noteFrequency, harmonicConfig: harmonicConfig)
        note.playNote(currentTime: startTime)
//        mixer.addInput(note.envelope)
//        note.playSound()
//        notesPlaying[notes[index]]?.shutdownSynth()
        notesPlaying[notes[index]] = note
        wavesSpawned.append(wave)
    }
    
    func killWave(_ id: UUID) {
        wavesParentNode.removeChildren(in: [wavesSpawned.first(where: { $0.id == id })!.waveNode])
        wavesSpawned.removeAll(where: { $0.id == id })
    }
    
    func dissipateWave(index: Int, currentTime: TimeInterval) {
        if notesPlaying.keys.contains(notes[index]) {
//            notesPlaying[notes[index]]!.killSound()
            notesPlaying[notes[index]]!.stopNote(currentTime: currentTime)
        }
        wavesSpawned.first(where: { $0.index == index && $0.didRelease == false })?.dissipateWave(endTime: currentTime)
    }
    
    func updateFrames(currentTime: TimeInterval) {
        for note in notesPlaying.values {
            note.update(currentTime: currentTime)
        }
    }
}
