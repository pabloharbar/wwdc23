//
//  File.swift
//  
//
//  Created by Pablo Penas on 16/04/23.
//

import AVFoundation
import Foundation

typealias Signal = (Float) -> (Float)

class Synth {
    // MARK: Properties
    public var volume: Float {
        set {
            audioEngine.mainMixerNode.outputVolume = newValue
        }
        get {
            return audioEngine.mainMixerNode.outputVolume
        }
    }
    private var audioEngine: AVAudioEngine
    private var time: Float = 0
    private let sampleRate: Double
    private let deltaTime: Float
    
    private lazy var sourceNode = AVAudioSourceNode { (_, _, frameCount, audioBufferList) -> OSStatus in
        let ablPointer = UnsafeMutableAudioBufferListPointer(audioBufferList)
        for frame in 0..<Int(frameCount) {
            let sampleVal = self.signal(self.time)
            self.time += self.deltaTime
            for buffer in ablPointer {
                let buf: UnsafeMutableBufferPointer<Float> = UnsafeMutableBufferPointer(buffer)
                buf[frame] = sampleVal
            }
        }
        return noErr
    }
    
    private var signal: Signal
    
    private var playTime: TimeInterval = TimeInterval(0)
    private var releaseTime: TimeInterval = TimeInterval(0)
    private var baseFrequency: Float
    var isPlayingSound = false
    var didReleaseNote = false
    var harmonicConfig: HarmonicConfig
    let mainMixer: AVAudioMixerNode
    
    // MARK: Init
    
    init(baseFrequency: Float, harmonicConfig: HarmonicConfig = HarmonicConfig(first: 1.0, second: 0.301, third: 0.177, fourth: 0.114, fifth: 0.092)) {
        self.baseFrequency = baseFrequency
        audioEngine = AVAudioEngine()

        
        mainMixer = audioEngine.mainMixerNode
        let outputNode = audioEngine.outputNode
        let format = outputNode.inputFormat(forBus: 0)


        sampleRate = format.sampleRate
        deltaTime = 1 / Float(sampleRate)
        
        self.harmonicConfig = harmonicConfig
        let oscillator = BaseOscillator(amplitude: 1, frequency: baseFrequency, harmonicConfig: harmonicConfig)
        self.signal = oscillator.sineFunction

        let inputFormat = AVAudioFormat(commonFormat: format.commonFormat, sampleRate: sampleRate, channels: 1, interleaved: format.isInterleaved)
        audioEngine.attach(sourceNode)
        audioEngine.connect(sourceNode, to: mainMixer, format: inputFormat)
        audioEngine.connect(mainMixer, to: outputNode, format: nil)
        mainMixer.outputVolume = 0
        do {
           try audioEngine.start()
        } catch {
           print("Could not start engine: \(error.localizedDescription)")
        }
    }
    
    func updateHarmonicConfig(config: HarmonicConfig) {
        let oscillator = BaseOscillator(amplitude: 1, frequency: baseFrequency, harmonicConfig: config)
        self.signal = oscillator.sineFunction
    }
    
    func updateFrequency(frequency: Float) {
        baseFrequency = frequency
        let oscillator = BaseOscillator(amplitude: 1, frequency: baseFrequency, harmonicConfig: harmonicConfig)
        self.signal = oscillator.sineFunction
    }
    
//    func connectAudioNode() {
//        let mainMixer = audioEngine.mainMixerNode
//        let outputNode = audioEngine.outputNode
//        let format = outputNode.inputFormat(forBus: 0)
//        let inputFormat = AVAudioFormat(commonFormat: format.commonFormat, sampleRate: sampleRate, channels: 1, interleaved: format.isInterleaved)
//        audioEngine.attach(sourceNode)
//        audioEngine.connect(sourceNode, to: mainMixer, format: inputFormat)
//        audioEngine.connect(mainMixer, to: outputNode, format: nil)
//    }
    
    func playNote(currentTime: TimeInterval) {
        self.playTime = currentTime
        self.isPlayingSound = true
        self.didReleaseNote = false
    }
    
    func stopNote(currentTime: TimeInterval) {
        self.releaseTime = currentTime
        self.didReleaseNote = true
    }
    
    func update(currentTime: TimeInterval) {
        if isPlayingSound {
            let attackDuration: Double = 0.01
            let decayDuration: Double = 0.1
            let sustainLevel: Double = 0.2
            let releaseDuration: Double = 0.3
            if currentTime - playTime < attackDuration {
                self.volume = Float((currentTime - playTime) / attackDuration)
            } else if currentTime - playTime < attackDuration + decayDuration {
                self.volume = 1 - Float(1 - sustainLevel) * Float((currentTime - playTime - attackDuration) / decayDuration)
            } else if didReleaseNote {
                let vol = sustainLevel * (1 - (currentTime - releaseTime) / releaseDuration)
                if vol <= 0 {
                    self.volume = 0
                    isPlayingSound = false
                    didReleaseNote = false
                } else {
                    self.volume = Float(vol)
                }
            } else {
                self.volume = Float(sustainLevel)
            }
        }
    }
    
    func shutdownSynth() {
        audioEngine.disconnectNodeInput(mainMixer)
        audioEngine.detach(sourceNode)
        audioEngine.stop()
    }
}
