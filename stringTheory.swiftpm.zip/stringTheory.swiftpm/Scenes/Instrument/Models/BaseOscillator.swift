//
//  File.swift
//  
//
//  Created by Pablo Penas on 16/04/23.
//

import Foundation

struct BaseOscillator {
    var amplitude: Float = 1
    var frequency: Float = 440
    var harmonicConfig: HarmonicConfig = HarmonicConfig()
    var sineFunction: (Float) -> Float
    
    init(amplitude: Float, frequency: Float, harmonicConfig: HarmonicConfig) {
        self.amplitude = amplitude
        self.frequency = frequency
        self.harmonicConfig = harmonicConfig
        self.sineFunction = { (time: Float) -> Float in
//            var amp = amplitude
            var functionValue = harmonicConfig.first * sin(2.0 * Float.pi * frequency * time)
            functionValue += harmonicConfig.second * sin(2 * 2.0 * Float.pi * frequency * time)
            functionValue += harmonicConfig.third * sin(3 * 2.0 * Float.pi * frequency * time)
            functionValue += harmonicConfig.fourth * sin(4 * 2.0 * Float.pi * frequency * time)
            functionValue += harmonicConfig.fifth * sin(5 * 2.0 * Float.pi * frequency * time)
            return amplitude * functionValue
        }
    }
}
