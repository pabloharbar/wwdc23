import Foundation
import SpriteKit

class Wave {
    let id = UUID()
    private var parentNode: SKNode
    private var startTime: TimeInterval
    private var releaseTime: TimeInterval
    private var currentTime: TimeInterval
    private var frequency: CGFloat
    private var rotation: CGFloat
    var didRelease: Bool
    private var limitOffset: CGFloat
    private let velocity: Double = 20
    private let origin = CGPoint(x: 0, y: 0)
    
    var waveNode: SKShapeNode
    var index: Int
    
    init(parentNode: SKNode, startTime: TimeInterval, index: Int) {
        self.frequency = 0.5 + 0.5 * CGFloat(index) / 11
        self.rotation = .pi - CGFloat(1 + 2 * index) * .pi / 12
        self.index = index
        self.releaseTime = TimeInterval(0)
        self.didRelease = false
        self.limitOffset = 0
        
        self.parentNode = parentNode
        self.startTime = startTime
        self.currentTime = startTime
        self.waveNode = SKShapeNode()
        parentNode.addChild(waveNode)
    }
    
    func generateWave(nPeriods: CGFloat) {
        let path = UIBezierPath()
        let limit = 360 * nPeriods
        if didRelease {
            let x = origin.x + CGFloat(limitOffset / limit) * 45 * nPeriods
            let y = origin.y + CGFloat(cos(-12 * frequency * (currentTime - startTime) + frequency * limitOffset / 180.0 * .pi)) * CGFloat(limitOffset / limit) * 11 * nPeriods
            path.move(to: CGPoint(x: x, y: y))
        } else {
            path.move(to: origin)
        }

        for angle in stride(from: limitOffset, through: limit + limitOffset, by: 5.0) {
            let x = origin.x + CGFloat(angle / limit) * 45 * nPeriods
            let y = origin.y + CGFloat(cos(-12 * frequency * (currentTime - startTime) + frequency * angle / 180.0 * .pi)) * CGFloat(angle / limit) * 11 * nPeriods
            path.addLine(to: CGPoint(x: x, y: y))
            
        }
//        waveNode = SKShapeNode(path: path.cgPath)
        waveNode.path = path.cgPath
        waveNode.lineWidth = 10
        waveNode.strokeColor = UIColor(named: "Note\(index)")!
        waveNode.zRotation = self.rotation
    }
    
    func dissipateWave(endTime: TimeInterval) {
        releaseTime = endTime
        didRelease = true
    }
    
    func update(deltaTime: TimeInterval, killWaveFunction: @escaping (UUID) -> ()) {
        var nPeriods = frequency * velocity
        currentTime += deltaTime
        nPeriods *= didRelease ? (releaseTime - startTime) : (currentTime - startTime)
        if didRelease {
            limitOffset = 360 * frequency * velocity * (currentTime - releaseTime)
            if limitOffset / 360 > 17 {
                nPeriods -= limitOffset / 360 - 17
                if nPeriods <= 0 {
                    killWaveFunction(id)
                }
            }
        }
        generateWave(nPeriods: nPeriods)
        if didRelease {
            waveNode.alpha = 1 - limitOffset / (360 * 20)
        }
    }
}
