//
//  File.swift
//  
//
//  Created by Pablo Penas on 02/04/23.
//

import Foundation

struct HarmonicConfig: Equatable {
    var first: Float = 1.0
    var second: Float = 0.301
    var third: Float = 0.177
    var fourth: Float = 0.114
    var fifth: Float = 0.092
    func getHarmonicsList() -> [Int] {
        var harmonics: [Int] = []
        if self.first != 0 {
            harmonics.append(1)
        }
        if self.second != 0 {
            harmonics.append(2)
        }
        if self.third != 0 {
            harmonics.append(3)
        }
        if self.fourth != 0 {
            harmonics.append(4)
        }
        if self.fifth != 0 {
            harmonics.append(5)
        }
        return harmonics
    }
    
    func getHarmonicValue(index: Int) -> Float {
        switch index {
        case 1:
            return self.first
        case 2:
            return self.second
        case 3:
            return self.third
        case 4:
            return self.fourth
        case 5:
            return self.fifth
        default:
            return 1.0
        }
    }
}

//class Note {
//    private let baseNote: Float
//    private var oscillators: [Oscillator] = []
//    private let mixer: Mixer
//    let envelope: AmplitudeEnvelope
//    let harmonicConfig: HarmonicConfig
//
//    init(baseNote: Float, harmonicConfig: HarmonicConfig = HarmonicConfig()) {
//        self.baseNote = baseNote
//        self.harmonicConfig = harmonicConfig
//        self.mixer = Mixer()
//        self.envelope = AmplitudeEnvelope(mixer)
//        for i in harmonicConfig.getHarmonicsList() {
//            let oscillator = createAndStartOscillator(frequency: baseNote * Float(i), amplitude: harmonicConfig.getHarmonicValue(index: i))
//            oscillators.append(oscillator)
//        }
//        for oscillator in oscillators {
//            mixer.addInput(oscillator as Node)
//        }
//        mixer.volume = 1
//        envelope.attackDuration = 0.01
//        envelope.decayDuration = 0.1
//        envelope.sustainLevel = 0.1
//        envelope.releaseDuration = 0.3
//    }
//
//    func playSound() {
//        envelope.openGate()
//    }
//
//    func killSound() {
//        envelope.closeGate()
//    }
//
//    func createAndStartOscillator(frequency: Float, amplitude: Float) -> Oscillator {
//        let oscillator = Oscillator()
//        oscillator.frequency = frequency
//        oscillator.amplitude = amplitude
//        oscillator.start()
//        return oscillator
//    }
//}


//class Note {
//    private let baseNote: Float
//    private var oscillators: [Oscillator] = []
//    private let mixer: Mixer
//    let envelope: AmplitudeEnvelope
//    let harmonicConfig: HarmonicConfig
//
//    init(baseNote: Float, harmonicConfig: HarmonicConfig = HarmonicConfig()) {
//        self.baseNote = baseNote
//        self.harmonicConfig = harmonicConfig
//        self.mixer = Mixer()
//        self.envelope = AmplitudeEnvelope(mixer)
//        for i in harmonicConfig.getHarmonicsList() {
//            let oscillator = createAndStartOscillator(frequency: baseNote * Float(i), amplitude: harmonicConfig.getHarmonicValue(index: i))
//            oscillators.append(oscillator)
//        }
//        for oscillator in oscillators {
//            mixer.addInput(oscillator as Node)
//        }
//        mixer.volume = 1
//        envelope.attackDuration = 0.01
//        envelope.decayDuration = 0.1
//        envelope.sustainLevel = 0.1
//        envelope.releaseDuration = 0.3
//    }
//
//    func playSound() {
//        envelope.openGate()
//    }
//
//    func killSound() {
//        envelope.closeGate()
//    }
//
//    func createAndStartOscillator(frequency: Float, amplitude: Float) -> Oscillator {
//        let oscillator = Oscillator()
//        oscillator.frequency = frequency
//        oscillator.amplitude = amplitude
//        oscillator.start()
//        return oscillator
//    }
//}
