//
//  InstrumentScene.swift
//  wwdc23
//
//  Created by Pablo Penas on 25/03/23.
//

import SpriteKit

class InstrumentScene: SKScene {
    var lastUpdate = TimeInterval(0)
    var center = SKShapeNode(circleOfRadius: 600)
    var octaveManager = OctaveManager()
    var indicesPlaying: [Int] = []
    
    var speechBubble = SKShapeNode()
    var speechText = SKLabelNode(text: "")
    var freeze = true
    var speechBubbleVisible = true
    var settingsTouched = false
    
    private var settingsButton = SKNode()
    var openHUD: () -> () = {}
    
    override func didMove(to view: SKView) {
        speechBubble = SKShapeNode(rect: CGRect(x: -800, y: 360, width: 1600, height: 180), cornerRadius: 20)
        speechBubble.strokeColor = UIColor(named: "BorderColor")!
        speechBubble.fillColor = UIColor(named: "DialogBackground")!
        speechBubble.zPosition = 10
        
        speechText.text = "Touch or swipe the notes A, A#, B... to play a sound, and adjust the harmonics to create your own instrument"
        speechText.fontName = "SF Pro Rounded"
        speechText.fontSize = 48
        speechText.numberOfLines = -1
        speechText.preferredMaxLayoutWidth = 1500
        speechText.horizontalAlignmentMode = .left
        speechText.verticalAlignmentMode = .top
        speechText.position = CGPoint(x: -750, y: 512)
        speechText.zPosition = 11
        speechText.startTyping(TimeInterval(0.01), completion: {
            self.run(SKAction.wait(forDuration: 3)) {
                self.freeze = false
            }
        })
        
        settingsButton.position = CGPoint(x: 740, y: -440)
        settingsButton.zPosition = 1
        
        self.addChild(speechText)
        self.addChild(speechBubble)
        
        self.view?.isMultipleTouchEnabled = true
        self.center.fillColor = .clear
        self.center.strokeColor = .white
        self.center.position = CGPoint(x: 0,y: 0)
        self.addChild(center)
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.createNoteAreas()
        self.addChild(octaveManager.wavesParentNode)
        self.addChild(settingsButton)
        createConfigButton()
    }
    
    func createConfigButton(backgroundColor: UIColor = .black) {
        settingsButton.removeAllChildren()
        let background = SKShapeNode(rect: CGRect(x: -71, y: -66, width: 142, height: 132), cornerRadius: 20)
        background.fillColor = backgroundColor
        background.strokeColor = UIColor(named: "BorderColor")!
        background.lineWidth = 5
        background.zPosition = 1
        
        let config = UIImage.SymbolConfiguration(pointSize: 80)
        let image = UIImage(systemName: "gearshape.fill", withConfiguration: config)!.withTintColor(UIColor.white)
        let data = image.pngData()
        let newImage = UIImage(data:data!)
        let texture = SKTexture(image: newImage!)
//        let image = UIImage(named: currentInstrument == .guitar ? "acousticGuitarIcon" : "electricGuitarIcon")!
//        let texture = SKTexture(image: image)
        let instrumentImage = SKSpriteNode(texture: texture, size: CGSize(width: 106, height: 96))
        instrumentImage.zPosition = 2
        settingsButton.addChild(background)
        settingsButton.addChild(instrumentImage)
    }
    
    func createNoteAreas() {
        for (i, note) in octaveManager.notes.enumerated() {
            let path = CGMutablePath()
            let center = CGPoint(x: 0, y: 0)
//            let endPoint = CGPoint(x: 600 * cos(CGFloat(i) * .pi/6), y: 600 * sin(CGFloat(i) * .pi/6))
            let endPoint = CGPoint(x: 600 * cos(.pi - CGFloat(i) * .pi/6), y: 600 * sin(CGFloat(i) * .pi/6))
            
            path.move(to: center)
            path.addLine(to: endPoint)
            
            let pathNode = SKShapeNode(path: path)
            pathNode.strokeColor = .white
            pathNode.lineWidth = 3
            
            let labelNode = SKLabelNode(fontNamed: "SF Pro Rounded")
            labelNode.text = note
            labelNode.fontSize = 100
            labelNode.fontColor = .white.withAlphaComponent(0.5)
            labelNode.verticalAlignmentMode = .center
            labelNode.horizontalAlignmentMode = .center
//            labelNode.position = CGPoint(x: 400 * cos((CGFloat(i) + 0.5) * .pi/6), y: 400 * sin((CGFloat(i) + 0.5) * .pi/6))
            labelNode.position = CGPoint(x: 400 * cos(.pi - (CGFloat(i) + 0.5) * .pi/6), y: 400 * sin(.pi - (CGFloat(i) + 0.5) * .pi/6))
            
            self.addChild(pathNode)
            self.addChild(labelNode)
        }
    }
    
    func updateHarmonicConfig(config: HarmonicConfig) {
        octaveManager.harmonicConfig = config
    }
    

    func touchDown(at pos: CGPoint) {
        if settingsButton.contains(pos) {
            openHUD()
            settingsTouched = true
        } else if !settingsButton.contains(pos) {
            if speechBubbleVisible && !freeze {
                self.removeChildren(in: [speechText, speechBubble])
                speechBubbleVisible = false
            }
            var angle: CGFloat = atan(-pos.y/pos.x) * 180 / .pi
            if pos.y < 0 || pos.x > 0 {
                angle += 180
                if pos.x < 0 {
                    angle += 180
                }
            } else if pos.x == 0 {
                angle += 180
            }
            let index = Int(12 * angle / 360)
            print(index, angle)
            if !indicesPlaying.contains(index) {
                indicesPlaying.append(index)
                octaveManager.emitWave(index: index, startTime: lastUpdate)
            }
        }
    }
    
    func touchUp(at pos: CGPoint) {
        if settingsTouched {
            settingsTouched = false
        }
        var angle: CGFloat = atan(-pos.y/pos.x) * 180 / .pi
        if pos.y < 0 || pos.x > 0 {
            angle += 180
            if pos.x < 0 {
                angle += 180
            }
        } else if pos.x == 0 {
            angle += 180
        }
        let index = Int(12 * angle / 360)
        if indicesPlaying.contains(index) {
            octaveManager.dissipateWave(index: index, currentTime: lastUpdate)
            indicesPlaying.removeAll(where: {$0 == index})
        }
    }
    
    func touchMoved(at pos: CGPoint) {
        if !settingsTouched {
            var angle: CGFloat = atan(-pos.y/pos.x) * 180 / .pi
            if pos.y < 0 || pos.x > 0 {
                angle += 180
                if pos.x < 0 {
                    angle += 180
                }
            } else if pos.x == 0 {
                angle += 180
            }
            let index = Int(12 * angle / 360)
            print(index, angle)
            if !indicesPlaying.contains(index) {
                for ind in indicesPlaying {
                    octaveManager.dissipateWave(index: ind, currentTime: lastUpdate)
                }
                indicesPlaying = []
                octaveManager.emitWave(index: index, startTime: lastUpdate)
                indicesPlaying.append(index)
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchUp(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchMoved(at: t.location(in: self))
            // Multi touch
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if lastUpdate == 0 {
            lastUpdate = currentTime
            return
        }
        
        let deltaTime = currentTime - lastUpdate
        lastUpdate = currentTime
        for wave in octaveManager.wavesSpawned {
            wave.update(deltaTime: deltaTime, killWaveFunction: octaveManager.killWave)
        }
        octaveManager.updateFrames(currentTime: lastUpdate)
    }
}
